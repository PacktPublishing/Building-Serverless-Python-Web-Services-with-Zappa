from __future__ import print_function

print('Loading function')


def lambda_handler(event, context):
    return "Hello World ! Response by lambda function."



